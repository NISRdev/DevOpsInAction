# terraform-sentinel-policies-azure
Terraform Cloud and Sentinel Policies Demo on Azure
